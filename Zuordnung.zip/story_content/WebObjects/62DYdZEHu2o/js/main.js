
const dropZone1 = document.querySelector('.drop-target1');
const dropZone2 = document.querySelector('.drop-target2');
const dropZone3 = document.querySelector('.drop-target3');
const dropZone4 = document.querySelector('.drop-target4');
const dropZone5 = document.querySelector('.drop-target5');
const draggedItems = document.querySelectorAll('.pictureCard');



$(document).ready(function(){
  $('.modal').modal();
});



for (var i = 0; i < draggedItems.length; i++) {
    draggedItems[i].addEventListener('dragstart', function (event) {

        console.log(event);
        event.dataTransfer.setData("Text", event.target.id);
    });
}



dropZone1.ondragover = (event) => {
    event.preventDefault();
    onDragFeedback(dropZone1);
}

dropZone1.ondrop = (event) => {
    event.preventDefault();
    const data = event.dataTransfer.getData("Text");
    const element = document.getElementById(data);
    var currentId = dropZone1.id;
    var currentDropZone = dropZone1;
    var currentId = dropZone1.id;
    checkDrop(element, currentId, currentDropZone);

}

dropZone2.ondragover = (event) => {
    event.preventDefault();
    onDragFeedback(dropZone2);
}

dropZone2.ondrop = (event) => {
    event.preventDefault();
    const data = event.dataTransfer.getData("Text");
    const element = document.getElementById(data);
    var currentDropZone = dropZone2;
    var currentId = dropZone2.id;
    checkDrop(element, currentId, currentDropZone);
    checkAllRemoved()

}
dropZone3.ondragover = (event) => {
    event.preventDefault();
    onDragFeedback(dropZone3);

}

dropZone3.ondrop = (event) => {
    event.preventDefault();
    const data = event.dataTransfer.getData("Text");
    const element = document.getElementById(data);
    var currentDropZone = dropZone3;
    var currentId = dropZone3.id;
    checkDrop(element, currentId, currentDropZone);
    checkAllRemoved()

}
dropZone4.ondragover = (event) => {
    event.preventDefault();
    onDragFeedback(dropZone4);
}


dropZone4.ondrop = (event) => {
    event.preventDefault();
    const data = event.dataTransfer.getData("Text");
    const element = document.getElementById(data);
    var currentDropZone = dropZone4;
    var currentId = dropZone4.id;
    checkDrop(element, currentId, currentDropZone);
    checkAllRemoved()

}
dropZone5.ondragover = (event) => {
    event.preventDefault();
    onDragFeedback(dropZone5);

}


dropZone5.ondrop = (event) => {
    event.preventDefault();
    const data = event.dataTransfer.getData("Text");
    const element = document.getElementById(data);
    var currentDropZone = dropZone5;
    var currentId = dropZone5.id;
    checkDrop(element, currentId, currentDropZone);
    checkAllRemoved()

}
function removeWhenRight(element) {

    initRightModal(element);
    element.remove();
}


function checkDrop(element, dropZoneID, current) {
    if (element.dataset.framework === dropZoneID) {
        setTimeout(() => {
            removeWhenRight(element);
            checkAllRemoved();
        }, 800)
        $(element).fadeOut("easing");


        rightFeedback(current);

    } else {

        wrongFeedback(current);
        initFalseModal(dropZoneID);
    }
}

function checkAllRemoved() {
    var cards = document.getElementsByClassName('pictureSize');
    console.log(cards);
    if (cards.length === 0) {
        dropZone1.remove();
        dropZone2.remove();
        dropZone3.remove();
        dropZone4.remove();
        dropZone5.remove();
        var modalContainer = document.getElementById('modalContainer');
        modalContainer.children[0].remove();

    }

}

function rightFeedback(dropzone) {
    setTimeout(() => {
        $(dropzone).removeClass('true');

    }, 1000);
    $(dropzone).addClass('true');



}
function onDragFeedback(currentDropZone){
    setTimeout(() => {
        $(currentDropZone).removeClass('dragOver');
    }, 800)
    $(currentDropZone).addClass('dragOver');
}
function wrongFeedback(dropzone) {
    setTimeout(() => {
        $(dropzone).removeClass('wrong');


    }, 600);
    $(dropzone).addClass('wrong');






}

//create Modals for Messaging
var numberOfModals = 0;
function createModal(srcPic, header, content) {
    var modalDiv = document.createElement('div');
    modalDiv.id = 'myModal';
    modalDiv.className = "modal ";
    modalDiv.display = "none";

    var modalContent = document.createElement('div');
    modalContent.className = "modal-content row";

    var modalColOne = document.createElement('div');
    modalColOne.className = "col s6";

    var head = document.createElement('h4');
    head.textContent = header;

    var paragraph = document.createElement('p');
    paragraph.textContent = content;

    var modalColTwo = document.createElement('div');
    modalColTwo.className = "col s6 ";

    var imageModal = document.createElement('img');
    imageModal.className = " img-rounded card-image modalSize";
    imageModal.src = srcPic;

    var modalFooter = document.createElement('div');
    modalFooter.className = "modal-footer col s12";

    var closeLink = document.createElement('a');
    closeLink.className = "modal-close myCloseBtn orange btn";
    closeLink.textContent= "OK";

    modalFooter.appendChild(closeLink);
    modalColTwo.appendChild(imageModal);

    modalColOne.appendChild(head);
    modalColOne.appendChild(paragraph);

    modalContent.appendChild(modalColOne);
    modalContent.appendChild(modalColTwo);
    modalContent.appendChild(modalFooter); 

    modalDiv.appendChild(modalContent);

    var modal = document.getElementById("modalContainer");
    modalDiv.style.display = "inline-flex";


    modal.appendChild(modalDiv);
    numberOfModals++;
}
function createFalseModal(header, content) {
    var modalDiv = document.createElement('div');
    modalDiv.id = 'myModal';
    modalDiv.className = "modal  ";
    modalDiv.display = "none";


    var modalContent = document.createElement('div');
    modalContent.className = "modal-content row";

    var modalColOne = document.createElement('div');
    modalColOne.className = "col s12";

    var head = document.createElement('h4');
    head.textContent = header;

    var paragraph = document.createElement('p');
    paragraph.textContent = content;

    var modalFooter = document.createElement('div');
    modalFooter.className = "modal-footer col s12";

    var closeLink = document.createElement('a');
    closeLink.className = "modal-close myCloseBtn orange btn";
    closeLink.textContent= "OK";

    modalFooter.appendChild(closeLink);

    modalColOne.appendChild(head);
    modalColOne.appendChild(paragraph);

    modalContent.appendChild(modalColOne);
    modalContent.appendChild(modalFooter); 

    modalDiv.appendChild(modalContent);

    var modal = document.getElementById("modalContainer");
    modalDiv.style.display = "inline-flex";
    modal.appendChild(modalDiv);

    numberOfModals++;
}
function initFalseModal(dropzoneId) {
    if (dropzoneId === "Honigbiene") {
        createFalseModal("Stimmt nicht", "Das ist keine Honigbiene. Die Honigbiene ist gekennzeichnet durch ein abgeflachtes Hinterbein (1. Tarsenglied).");
    } else if (dropzoneId === "Hummel") {
        createFalseModal("Stimmt nicht", "Hummeln haben einen gedrungenen Körperbau und eine starke Behaarung. Deswegen fliegen sie im Gegensatz zu anderen Wildbienen auch bei kühleren Temperaturen.");
    } else if (dropzoneId === "Wildbiene") {
        createFalseModal("Stimmt nicht", "Wildbienen sind häufig kleiner als Honigbienen und haben kein abgeflachtes Hinterbein.");
    } else if (dropzoneId === "Schwebfliege") {
        createFalseModal("Stimmt nicht", "Schwebfliegen haben große, bei den Männchen dicht beieinanderliegende Augen. Die Fühler sind kurz. Außerdem haben Schwebfliegen nur ein Flügelpaar.");
    } else if (dropzoneId === "Wespe") {
        createFalseModal("Stimmt nicht", "Wespen erkennt man an der typischen Wespentaille.");
    }
    $(document).ready(openModal());
}

function initRightModal(element) {
    if (element.id === "draggedItem1") {
        createModal("./img/BubphtalWildbiene.jpg", "Stimmt!", "Das ist eine kleine Wildbiene an einer Blüte von Buphthalum salicifolium (Ochsenauge oder Goldmargerite). Auch sie ist im Verleich zur Honigbiene deutlich kleiner und hat einen sehr biel schmaleren Körperbau.");
    } else if (element.id === "draggedItem2") {
        createModal("./img/Faltenwespe.jpg", "Stimmt!", "Das ist eine Faltenwespe (Symmorphus gracilis) an einer künsltichen Nisthilfe aus Ton. Sie erbeutet Rüsselkäfer-Larven, die verproviantiert und den Nistgang mit Lehm verschließt. Wespen erkennt man an der typischen Wespentaille.");
    } else if (element.id === "draggedItem3") {
        createModal("./img/Gartenhummel.jpg", "Stimmt!", "Hummeln haben einen gedrungenen Körperbau und eine starke Behaarung. Deswegen fliegen sie auch bei kühleren Temperaturen. Bei dieser Hummel handelt es sich um die Gartenhummel (Bombus hortorum) auf einer Blüte von Delphinium Elatum.");
    } else if (element.id === "draggedItem4") {
        createModal("./img/gelbbindigeFruchenbiene.jpg", "Stimmt!", "Das ist eine Gelbbindige Furchenbiene (Halictus scabiosae) auf einer Skabiosenblüte, der sie ihren Namen verdankt. Sie hat einen schlankeren Körperbau im Vergleich zur Honigbiene ist aber fast gleich groß.");
    } else if (element.id === "draggedItem5") {
        createModal("./img/Honigbiene.jpg", "Stimmt!", "Das ist eine Honigbiene (Apis mellifera) auf einer Blüte der einjährigen Bidens. Man erkennt Honigbienen leicht an dem abgeflachten Hinterbein (1. Tarsenglied).");
    } else if (element.id === "draggedItem6") {
        createModal("./img/LavandulaSchwebfliege.jpg", "Stimmt!", "Das ist eine Schwebfliege auf einer Blüte von Lavandula angustifolia. Man erkennt sie an ihren großen, bei Männchen dicht beieinanderliegenden Augen. Die Fühler sind kurz. Außerdem haben Schwebfliegen nur ein Flügelpaar. Der eckige Flug der Schwebfliegen ist sehr auffällig.");
    } else if (element.id === "draggedItem7") {
        createModal("./img/Pollenhöschen.jpg", "Stimmt!", "Das ist eine kleine Wildbiene an einer Blüte von Geranium sanguineum var. striatum. Im Vergleich zur Honigbiene ist sie etwas kleiner und hat eine weniger deutliche schwarz-gelbe Färbung. Man sieht hier deutlich die Pollenhöschen, in denen sie den Pollen sammelt. Vermutlich Rotschöpfige Sandbiene (Andrena haemorrhoa).");
    } else if (element.id === "draggedItem8") {
        createModal("./img/SchwebfliegeEchinacea.jpg", "Stimmt!", "Das ist eine Schwebfliege auf einer Blüte einer Echinacea. Man erkennt sie an ihren großen, bei den Männchen dicht beieinanderliegenden Augen. Die Fühler sind kurz. Außerdem haben Schwebfliegen nur ein Flügelpaar. Der eckige Flug der Schwebfliegen ist sehr auffällig.");
    } else if (element.id === "draggedItem9") {
        createModal("./img/SchwebliegeCatananche.jpg", "Stimmt!", "Das ist eine Schwebfliege auf eine Catananche-Blüte. Man erkennt sie an ihren großen, bei den Männchen dicht beieinanderliegenden Augen. Die Fühler sind kurz. Außerdem haben Schwebfliegen nur ein Flügelpaar. Der eckige Flug der Schwebfliegen ist sehr auffällig.");
    } else if (element.id === "draggedItem10") {
        createModal("./img/stahlblaueGrillenjaeger.jpg", "Stimmt!", "Auch das ist eine Wespe auf einer Eryngium planum-Blüte (Mannstreu). Es sit der Stahlblaue Grillenjäger (Isodontia mexicana). Wespen erkennt man an der typischen Wespentaille.");
    } else if (element.id === "draggedItem11") {
        createModal("./img/Steinhummel.jpg", "Stimmt!", "Hummeln haben einen gedrungenen Körperbau und eine starke Behaarung. Deswegen fliegen sie auch bei kühleren Temperaturen. Bei diesem Exemplar handelt es sich um die Steinhummel (Bombus lapidarius) auf einer Blüte von Scabiosa columbaria.");
    }
    $(document).ready(openModal());
}
function openModal(){ 
    $('.modal').modal({
        backdrop: "static",
        keyboard: false
    });
    $('.modal').modal();
    
    $("#mymodal:last-child").modal('open');
}

